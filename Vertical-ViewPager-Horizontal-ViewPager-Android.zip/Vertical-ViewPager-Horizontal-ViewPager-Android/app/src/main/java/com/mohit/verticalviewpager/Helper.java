package com.mohit.verticalviewpager;

import android.util.Log;

/**
 * Created by mohit on 29/12/16.
 */

public  class Helper {

    public static void log(String msg){
        Log.e("Debugger_Key",msg);
    }
}
